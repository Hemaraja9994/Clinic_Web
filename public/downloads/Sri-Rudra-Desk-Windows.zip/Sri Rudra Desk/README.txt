Sri Rudra Speech & Hearing Clinic — desk for Windows
========================================================

This folder runs the clinic desk on this computer. Collections, the daily
note, and clinic details are saved in this browser on this PC. After the
first open, it keeps working with the internet switched off.

Clinic already filled in
------------------------
Sri Rudra · MVP Double Road
Flat No. 211 & 212, HIG-207/4, Second Floor, Beside Kotak Mahindra Bank,
Bhavana Heights, MVP Double Road, Visakhapatnam-530017.
Phones: 9849848516 · 9032389666 · 7032054275
Email: srirudraspeechandhearing@gmail.com

How to start
------------
1. Unzip this folder somewhere you can find it (for example the Desktop).
2. Double-click "Start Sri Rudra Desk.bat".
3. Leave the black window open while you work. Closing it stops the desk.
4. The browser opens. The first time, create a username and password for
   this computer. It is not filled in again after you sign out.

What you can record
-------------------
- One service, including PTA + Impedance, PTA + Impedance + Tinnitus,
  and BERA & OAE.
- Several services from one visit (Choose services). Presets fill
  PTA and Impedance, or those two plus Tinnitus, or BERA and OAE.
  Huggies, ear tips and domes are in the same list for every clinic.
- A phone number on each collection.
- A note on the dashboard for the day.

Phone
-----
On the clinic Wi-Fi, open this address in Chrome on the phone:

  https://srirudraspeechandhearing.com/desk.html

Tap the browser menu, then Install app (Android) or Share, then
Add to Home Screen (iPhone). Open it once while you are online.
After that the icon opens without internet. Records on the phone
stay on the phone until you export them.

Moving records between the PC and a phone
------------------------------------------
Collections → Export backup. Send that file (WhatsApp, USB, or mail).
On the other device: Collections → Import backup.

This desk is separate from the online admin portal. Export a backup
if you need the same rows in both places.
